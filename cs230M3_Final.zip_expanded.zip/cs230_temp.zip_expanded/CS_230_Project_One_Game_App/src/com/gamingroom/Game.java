package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Game extends Entity {

    // List of teams competing in this game
    private List<Team> teams = new ArrayList<Team>();

    /**
     * Hide the default constructor to prevent creating empty instances.
     */
    private Game() {
        super(0, "");
    }

   
    public Game(long id, String name) {
        super(id, name);
    }

    
    public Team addTeam(String name) {

       
        Team team = null;

       
        Iterator<Team> it = teams.iterator();
        while (it.hasNext()) {
            Team existingTeam = it.next();
            if (existingTeam.getName().equalsIgnoreCase(name)) {
                // Found a match — return the existing team
                team = existingTeam;
                break;
            }
        }

        // Only create and add a new team if no match was found
        if (team == null) {
            // Obtain the next team id from the singleton GameService
            team = new Team(GameService.getInstance().getNextTeamId(), name);
            teams.add(team);
        }

        return team;
    }

    @Override
    public String toString() {
        return "Game [id=" + getId() + ", name=" + getName() + "]";
    }
}
