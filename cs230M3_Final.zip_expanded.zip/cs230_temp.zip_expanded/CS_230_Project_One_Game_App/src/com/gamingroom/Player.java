package com.gamingroom;


public class Player extends Entity {

    /**
     * Constructor with an identifier and name.
     *
     * @param id   unique identifier for this player
     * @param name unique name for this player
     */
    public Player(long id, String name) {
        // Delegate to the Entity superclass constructor
        super(id, name);
    }

    @Override
    public String toString() {
        return "Player [id=" + getId() + ", name=" + getName() + "]";
    }
}
