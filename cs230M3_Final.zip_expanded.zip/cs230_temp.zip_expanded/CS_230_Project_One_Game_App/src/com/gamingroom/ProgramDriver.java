package com.gamingroom;


public class ProgramDriver {

    /**
     * The one-and-only main() method.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        // Obtain reference to the singleton GameService instance
        GameService service = GameService.getInstance();

        System.out.println("\nAbout to test initializing game data...");

        // Initialize with some game data
        Game game1 = service.addGame("Game #1");
        System.out.println(game1);

        Game game2 = service.addGame("Game #2");
        System.out.println(game2);

        // Add teams to game1; duplicate name should return the same instance
        Team team1 = game1.addTeam("Team Alpha");
        System.out.println(team1);

        Team team1Dup = game1.addTeam("Team Alpha"); // should return existing
        System.out.println("Duplicate team add returned same instance: " + (team1 == team1Dup));

        Team team2 = game1.addTeam("Team Beta");
        System.out.println(team2);

        // Add players to team1; duplicate name should return the same instance
        Player player1 = team1.addPlayer("Alice");
        System.out.println(player1);

        Player player1Dup = team1.addPlayer("Alice"); // should return existing
        System.out.println("Duplicate player add returned same instance: " + (player1 == player1Dup));

        Player player2 = team1.addPlayer("Bob");
        System.out.println(player2);

        // Use another class to prove there is only one GameService instance
        SingletonTester tester = new SingletonTester();
        tester.testSingleton();
    }
}
