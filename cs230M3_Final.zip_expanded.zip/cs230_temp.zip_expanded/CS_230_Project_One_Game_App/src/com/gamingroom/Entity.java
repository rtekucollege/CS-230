package com.gamingroom;


public abstract class Entity {

    // Unique identifier for this entity
    private long id;

    // Human-readable name for this entity
    private String name;

    /**
     * Hide the default constructor to prevent creating empty instances.
     */
    private Entity() {
    }

    /**
     * Constructor with an identifier and name.
     *
     * @param id   unique identifier
     * @param name display name
     */
    public Entity(long id, String name) {
        this();
        this.id = id;
        this.name = name;
    }

    /**
     * @return the unique identifier
     */
    public long getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}
