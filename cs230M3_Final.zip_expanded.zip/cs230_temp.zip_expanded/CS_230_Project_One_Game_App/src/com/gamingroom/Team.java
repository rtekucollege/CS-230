package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team.
 * <p>
 * Extends Entity to inherit id and name attributes.
 * Each team maintains a list of players; player names must be unique
 * within a team. No mutators (setters) are defined so id and name
 * cannot be changed once a team is created.
 * </p>
 *
 * @author coce@snhu.edu
 */
public class Team extends Entity {

    // List of players belonging to this team
    private List<Player> players = new ArrayList<Player>();

    /**
     * Constructor with an identifier and name.
     *
     * @param id   unique identifier for this team
     * @param name unique name for this team
     */
    public Team(long id, String name) {
        // Delegate to the Entity superclass constructor
        super(id, name);
    }

    /**
     * Adds a new player to this team, or returns the existing player if the
     * name is already in use.
     * <p>
     * Uses the iterator pattern to traverse the player list and check for
     * duplicate names before adding a new instance.
     * </p>
     *
     * @param name unique name for the new player
     * @return the new or existing player instance
     */
    public Player addPlayer(String name) {

        // Local player reference; will hold result of search or new instance
        Player player = null;

        // Use an iterator to search for an existing player with the same name
        Iterator<Player> it = players.iterator();
        while (it.hasNext()) {
            Player existingPlayer = it.next();
            if (existingPlayer.getName().equalsIgnoreCase(name)) {
                // Found a match — return the existing player
                player = existingPlayer;
                break;
            }
        }

        // Only create and add a new player if no match was found
        if (player == null) {
            // Obtain the next player id from the singleton GameService
            player = new Player(GameService.getInstance().getNextPlayerId(), name);
            players.add(player);
        }

        return player;
    }

    @Override
    public String toString() {
        return "Team [id=" + getId() + ", name=" + getName() + "]";
    }
}
