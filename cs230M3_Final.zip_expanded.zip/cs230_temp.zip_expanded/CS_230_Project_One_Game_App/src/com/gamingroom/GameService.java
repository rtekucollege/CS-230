package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class GameService {

    /** The active list of games managed by this service. */
    private static List<Game> games = new ArrayList<Game>();

    /** Tracks the next available game identifier. */
    private static long nextGameId = 1;

    /** Tracks the next available player identifier. */
    private static long nextPlayerId = 1;

    /** Tracks the next available team identifier. */
    private static long nextTeamId = 1;

    /**
     * The single shared instance of GameService (singleton).
     * Declared volatile to ensure thread-safe lazy initialization.
     */
    private static volatile GameService service = null;

    /**
     * Private constructor — prevents external instantiation and enforces the
     * singleton pattern.
     */
    private GameService() {
    }

    /**
     * Returns the one-and-only instance of GameService
     * @return the singleton GameService instance
     */
    public static GameService getInstance() {
        if (service == null) {
            // checks only on first iteration
            synchronized (GameService.class) {
                if (service == null) {
                    service = new GameService();
                }
            }
        }
        return service;
    }

    /**
     * Adds a new game with the given name, or returns the existing game if a
     * game with that name already exists.
     * Uses the iterator pattern to search the game list for a duplicate name
     * before creating a new instance.
     *
     * @param name unique name for the game
     * @return the new or existing game instance
     */
    public Game addGame(String name) {

        // Local game reference; will hold result of search or new instance
        Game game = null;

        // Use an iterator to look for an existing game with the same name
        Iterator<Game> it = games.iterator();
        while (it.hasNext()) {
            Game existingGame = it.next();
            if (existingGame.getName().equalsIgnoreCase(name)) {
                // Found a match — return the existing game
                game = existingGame;
                break;
            }
        }

        // If no existing game was found, create and register a new one
        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

    /**
     * Returns the game instance at the specified index position.
     *
     * @param index index position in the list to return
     * @return requested game instance
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Returns the game instance with the specified id.
     * Uses the iterator pattern to locate the game.
     * @param id unique identifier of the game to search for
     * @return the matching game instance or null if not found
     */
    public Game getGame(long id) {

        // Local game reference; populated when a match is found
        Game game = null;

        // Use an iterator to look for an existing game with the same id
        Iterator<Game> it = games.iterator();
        while (it.hasNext()) {
            Game existingGame = it.next();
            if (existingGame.getId() == id) {
                game = existingGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the game instance with the specified name.
     * Uses the iterator pattern to locate the game.
     * @param name unique name of the game to search for
     * @return the matching game instance, or null if not found
     */
    public Game getGame(String name) {

        // Local game reference; populated when a match is found
        Game game = null;

        // Use an iterator to look for an existing game with the same name
        Iterator<Game> it = games.iterator();
        while (it.hasNext()) {
            Game existingGame = it.next();
            if (existingGame.getName().equalsIgnoreCase(name)) {
                game = existingGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the number of games currently active.
     *
     * @return count of active games
     */
    public int getGameCount() {
        return games.size();
    }

    /**
     * Returns the next available player identifier and increments the counter.
     *
     * @return next player id
     */
    public long getNextPlayerId() {
        return nextPlayerId++;
    }

    /**
     * Returns the next available team identifier and increments the counter.
     *
     * @return next team id
     */
    public long getNextTeamId() {
        return nextTeamId++;
    }
}
