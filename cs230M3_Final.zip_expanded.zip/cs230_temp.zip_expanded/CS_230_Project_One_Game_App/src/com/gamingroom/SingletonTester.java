package com.gamingroom;


public class SingletonTester {

    /**
     * Obtains the singleton GameService and prints all active games to confirm
     * that both classes share the same instance.
     */
    public void testSingleton() {

        System.out.println("\nAbout to test the singleton...");

        // Obtain the singleton GameService instance
        GameService service = GameService.getInstance();

        // Print all games currently registered with the service
        for (int i = 0; i < service.getGameCount(); i++) {
            System.out.println(service.getGame(i));
        }
    }
}
